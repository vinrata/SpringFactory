#  **Spring Factory - an additional spooky moon for your modpack** 
The Spring Factory has been long abandoned.  Coils and springs used to be manufactured here. 


![Screenshot_9](https://github.com/lilswisher/lethalmooncompany/blob/main/EtherUnreleasedReadMeFinal.jpg?raw=true)
# ⚙️ **This mod has many unique features for a custom moon mod** ⚙️

-Coil Heads are the only enemies that spawn here.
-6 Fire Exits. Pop in and out of fire exits to avoid coil heads.
-Ladders may help reach some fire exits.


- The Spring Factory moom requires Lethal Expansion SDK or the Core



